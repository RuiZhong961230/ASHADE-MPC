import os
from copy import deepcopy
from scipy.stats import cauchy
from opfunu.cec_based.cec2020 import *
import warnings
from opfunu.cec_based.cec2022 import *
import random
warnings.filterwarnings("ignore")

PopSize = 50
DimSize = 10
LB = [-100] * DimSize
UB = [100] * DimSize
TrialRuns = 50
curFEs = 0
MaxFEs = DimSize * 1000

Pop = np.zeros((PopSize, DimSize))
FitPop = np.zeros(PopSize)

FuncNum = 0

H = 5
muF = [0.3] * H
muCr = [0.5] * H

Fail_F = []
Fail_Cr = []


def meanL(arr):
    numer = 0
    denom = 0
    for var in arr:
        numer += var ** 2
        denom += var
    return numer / denom


def Initialization(func):
    global Pop, FitPop, curFEs, DimSize, muF, muCr, H, Fail_F, Fail_Cr
    for i in range(PopSize):
        for j in range(DimSize):
            Pop[i][j] = LB[j] + (UB[j] - LB[j]) * np.random.rand()
        FitPop[i] = func(Pop[i])
        curFEs += 1
    muF = [0.5] * H
    muCr = [0.5] * H
    Fail_F, Fail_Cr = [], []


def ASHADE_MPC(func):
    global Pop, FitPop, LB, UB, PopSize, DimSize, curFEs, Fail_F, Fail_Cr
    Off = np.zeros((PopSize, DimSize))
    FitOff = np.zeros(PopSize)
    F_idx, Cr_idx = np.random.randint(H), np.random.randint(H)
    Success_F, Success_Cr = [], []
    P1 = 1 - curFEs / MaxFEs
    for i in range(PopSize):
        IDX1 = np.random.randint(0, PopSize)
        while IDX1 == i:
            IDX1 = np.random.randint(0, PopSize)
        candi = list(range(0, PopSize))
        candi.remove(i)
        candi.remove(IDX1)
        IDX2, r2, r3 = np.random.choice(candi, 3, replace=False)

        F = cauchy.rvs(muF[F_idx], 0.1)
        Cr = np.clip(np.random.normal(muCr[Cr_idx], 0.1), 0, 1)
        while True:  # F determination
            if F > 1:
                F = 1
                break
            elif F < 0:
                F = cauchy.rvs(muF[F_idx], 0.1)
            break

        if np.random.rand() < P1:
            if FitPop[IDX1] < FitPop[i] and FitPop[IDX2] < FitPop[i]:
                Off[i] = Pop[i] + F * (np.mean([Pop[IDX1], Pop[IDX2]], axis=0) - Pop[i]) + F * (Pop[r3] - Pop[r2])
            elif (FitPop[IDX1] < FitPop[i] and FitPop[IDX2] > FitPop[i]) or (
                    FitPop[IDX1] > FitPop[i] and FitPop[IDX2] < FitPop[i]):
                IDX = np.random.choice([IDX1, IDX2], 1, replace=False)[0]  # 修正索引选择
                Off[i] = Pop[i] + F * (
                        np.mean([Pop[IDX], Pop[np.argmin(FitPop)]], axis=0) - Pop[i]) + F * (
                                 Pop[r3] - Pop[r2])
            else:
                Off[i] = Pop[i] + F * (Pop[np.argmin(FitPop)] - Pop[i]) + F * (Pop[r3] - Pop[r2])
        else:
            Off[i] = Pop[np.argmin(FitPop)] + F * (Pop[r3] - Pop[r2])

        jrand = np.random.randint(0, DimSize)  # bin crossover
        for j in range(DimSize):
            if np.random.rand() < Cr or j == jrand:
                pass
            else:
                Off[i][j] = Pop[i][j]

        for j in range(DimSize):
            if Off[i][j] < LB[j] or Off[i][j] > UB[j]:
                Off[i][j] = np.random.uniform(LB[j], UB[j])

        FitOff[i] = func(Off[i])
        curFEs += 1
        if FitOff[i] < FitPop[i]:
            Success_F.append(F)
            Success_Cr.append(Cr)

    for i in range(PopSize):
        if FitOff[i] < FitPop[i]:
            Pop[i] = deepcopy(Off[i])
            FitPop[i] = FitOff[i]

    c = 0.1
    if len(Success_F) == 0:
        pass
    else:
        muF[F_idx] = (1 - c) * muF[F_idx] + c * meanL(Success_F)
    if len(Success_Cr) == 0:
        pass
    else:
        muCr[Cr_idx] = (1 - c) * muCr[Cr_idx] + c * np.mean(Success_Cr)


def RunASHADE_MPC(func):
    global curFEs, MaxFEs, TrialRuns, Pop, FitPop, DimSize
    All_Trial_Best = []
    for i in range(TrialRuns):
        Best_list = []
        curFEs = 0
        np.random.seed(21 + 88 * i)
        Initialization(func)
        Best_list.append(min(FitPop))
        while curFEs < MaxFEs:
            ASHADE_MPC(func)
            Best_list.append(min(FitPop))
        All_Trial_Best.append(Best_list)
    np.savetxt("./ASHADE_MPC_Data/CEC2022/F" + str(FuncNum) + "_" + str(DimSize) + "D.csv", All_Trial_Best, delimiter=",")


def main(dim):
    global FuncNum, DimSize, MaxFEs, Pop, LB, UB
    DimSize = dim
    Pop = np.zeros((PopSize, dim))
    MaxFEs = dim * 1000
    LB = [-100] * dim
    UB = [100] * dim

    CEC2022 = [F12022(Dim), F22022(Dim), F32022(Dim), F42022(Dim), F52022(Dim), F62022(Dim),
               F72022(Dim), F82022(Dim), F92022(Dim), F102022(Dim), F112022(Dim), F122022(Dim)]

    for i in range(len(CEC2022)):
        FuncNum = i + 1
        RunASHADE_MPC(CEC2022[i].evaluate)


if __name__ == "__main__":
    if os.path.exists('./ASHADE_MPC_Data/CEC2022') == False:
        os.makedirs('./ASHADE_MPC_Data/CEC2022')
    Dims = [10, 20]
    for Dim in Dims:
        main(Dim)
