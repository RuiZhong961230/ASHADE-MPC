import sys
import numpy as np
import torch
from sklearn.feature_selection import mutual_info_classif
from sklearn.metrics import accuracy_score, f1_score, recall_score
from sklearn.model_selection import cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from torch import optim, nn
import torchvision
from torch.utils.data import DataLoader
import pandas as pd
from pokemon0 import Pokemon
from torchvision.models import resnet18
import os
from utils import Flatten
import pickle
from torchvision import transforms, models
from  PIL import Image
import torch
import torchvision.models as models
import torch.nn as nn
import torch
import torch.nn as nn
import torchvision.models as models
from torch.utils.data import DataLoader, SubsetRandomSampler
import random
def evalute(model, loader):
    model.eval()
    correct = 0
    total = len(loader.dataset)
    total_val =0
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        with torch.no_grad():
            logits = model(x)
            pred = logits.argmax(dim=1)
        total_val += y.size(0)
        correct += torch.eq(pred, y).sum().float().item()
    return correct / total

def get_evaluate_acc_pred(model, loader):
    model.eval()
    correct = 0
    total = len(loader.dataset)
    total_val = 0
    predictions = []  

    for x, y in loader:
        x, y = x.to(device), y.to(device)
        with torch.no_grad():
            logits = model(x)
            pred = logits
            predictions.extend(pred.cpu().numpy())  
         
    return predictions
def get_evaluate_acc_pred0(model, loader):
    global device
    model.eval()

    correct = 0
    total = 0  
    predictions = []  

    for x, y in loader:
        x, y = x.to(device), y.to(device)
        with torch.no_grad():
            logits = model(x)
            
            pred = logits.argmax(dim=1)  
            predictions.extend(pred.cpu().numpy())  

       
        total += y.size(0)
        
        correct += (pred == y).sum().item()

    
    if total == 0:
        raise ValueError("The data loader does not provide any samples. Please check the configuration of the data loader.")

    accuracy = correct / total
    return accuracy, predictions


class Mobilenet_v2(nn.Module):
    def __init__(self):
        super().__init__()
        self.base = torchvision.models.mobilenet_v2(pretrained=True)
        
        for param in list(self.base.parameters())[:-15]:
            param.requires_grad = False
            
        self.block = nn.Sequential(
            nn.Linear(1280, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, 4),
        )
        self.base.classifier = nn.Sequential()
        self.base.fc = nn.Sequential()             
                
    def forward(self, x):
        x = self.base(x)
        x = self.block(x)
        return x   

class ConvNeXtModel(nn.Module):
    def __init__(self, num_classes=4):
        super().__init__()
        self.base = models.convnext_base(pretrained=True) 
        for param in list(self.base.parameters())[:-15]:
            param.requires_grad = False           
        
        self.base.classifier[2] = nn.Sequential(
            nn.Flatten(),  
            nn.Linear(self.base.classifier[2].in_features, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, num_classes)
        )      
        
    def forward(self, x):
        x = self.base(x)
        return x

class SwinTransformerModel(nn.Module):
    def __init__(self, num_classes=4):
        super(SwinTransformerModel, self).__init__()
        
        self.base = models.swin_t(weights='IMAGENET1K_V1')  
        for param in list(self.base.parameters())[:-15]:  
            param.requires_grad = False
        
        self.base.head = nn.Sequential(
            nn.Flatten(),  
            nn.Linear(self.base.head.in_features, 128),  
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, num_classes)  
        )   

    def forward(self, x):
        x = self.base(x)
        return x


num_classes = 4
model = SwinTransformerModel(num_classes=num_classes)

def set_seed(seed):
    random.seed(seed)                       
    np.random.seed(seed)                   
    torch.manual_seed(seed)                 
    torch.cuda.manual_seed(seed)            
    torch.cuda.manual_seed_all(seed)        
    torch.backends.cudnn.deterministic = True  
    torch.backends.cudnn.benchmark = False




def generativeModel():
    global device, x_train, y_train   
    batchsz =64
    lr = 1e-3
    epochs =21
    device = torch.device('cuda:0')
    parent_dir = os.path.dirname(os.getcwd())    
    script_path = os.path.abspath(__file__)    
    cwd_dir = os.path.dirname(script_path)
    model_name = ["mobilenet_v2_model","SwinTransformerModel","ConvNeXtModel"] 

    for index  in range(0,3):                   
        
        val_acc_Trial = np.zeros((11, epochs))
        train_acc_Trial = np.zeros((11, epochs))
        val_loss_Trial = np.zeros((11, epochs))
        train_loss_Trial = np.zeros((11, epochs))  
        #Set the number of repeated executions. If the number of repetitions is too large, 
        #the operation will be too slow. It is recommended to reduce the number of repetitions.      
        for ii in range(0, 30):  
            set_seed(42+index+ii )
            if model_name[index]=="mobilenet_v2_model":                
                model=Mobilenet_v2().to(device)             
            elif model_name[index]=="SwinTransformerModel":
                model=SwinTransformerModel().to(device)
            elif model_name[index]=="ConvNeXtModel":
                model=ConvNeXtModel().to(device)           
            else:
                pass
            
            print(f"Execute model {model_name[index]}: the {ii}th time -------------")         
            
            filemame = f"images{0}.csv"            
            train_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='train')
            val_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='val')
            test_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='test')
            
            indices = np.arange(len(train_db))  
            sampler = SubsetRandomSampler(indices )
            train_loader = DataLoader(train_db, batch_size=batchsz, sampler=sampler)
            val_loader = DataLoader(val_db, batch_size=batchsz, shuffle=False)
            
            optimizer = optim.Adam(model.parameters(), lr=lr )
            criteon = nn.CrossEntropyLoss()

            best_acc, best_epoch = 0, 0
            global_step = 0
            
            for epoch in range(epochs):
                correct_train = 0  
                total_train = 0  
                train_loss = 0  

                for step, (x, y) in enumerate(train_loader):
                   
                    x, y = x.to(device), y.to(device)

                    model.train()
                    logits = model(x,)
                    loss = criteon(logits, y)

                    regularization_loss = 0
                    for param in model.parameters():
                        regularization_loss += torch.norm(param).pow(2)
                    loss = loss + 0.01 * regularization_loss
                    optimizer.zero_grad()
                    loss.backward()
                    optimizer.step()                    
                    train_loss += loss.item()                    
                    _, preds = torch.max(logits, 1)  
                    correct_train += (preds == y).sum().item()
                    total_train += y.size(0)  
                    global_step += 1
                
                train_acc = correct_train / total_train
                avg_train_loss = train_loss / len(train_loader)

                # Verification Phase
                model.eval()
                val_loss = 0
                correct_val = 0
                total_val = 0

                with torch.no_grad():
                    for val_x, val_y in val_loader:
                        val_x, val_y = val_x.to(device), val_y.to(device)

                        logits = model(val_x)
                        loss = criteon(logits, val_y)
                        val_loss += loss.item()
                        _, val_preds = torch.max(logits, 1)
                        correct_val += (val_preds == val_y).sum().item()
                        total_val += val_y.size(0)
                avg_val_loss = val_loss / len(val_loader)
                val_acc = correct_val / total_val

                val_acc_Trial[ii, epoch] = val_acc
                train_acc_Trial[ii, epoch] = train_acc
                val_loss_Trial[ii, epoch] = avg_val_loss
                train_loss_Trial[ii, epoch] = avg_train_loss

                if epoch % 1 == 0:                    
                    if val_acc > best_acc:
                        best_epoch = epoch
                        best_acc = val_acc
                        dirp = cwd_dir
                        if os.path.exists(os.path.join(dirp,model_name[index],str(epochs))) == False:
                            os.makedirs(os.path.join(dirp,model_name[index],str(epochs)))
                        torch.save(model.state_dict(), f'{dirp}/{model_name[index]}/{str(epochs)}/best{ii}.mdl')                    


from sklearn.model_selection import train_test_split, cross_val_score
from scipy.stats import cauchy
from copy import deepcopy
  
PopSize = 10
DimSize = 3
LB = [-100] * DimSize
UB = [100] * DimSize
TrialRuns = 1
curFEs = 0
MaxFEs = DimSize * 1000

Pop = np.zeros((PopSize, DimSize))
FitPop = np.zeros(PopSize)
Pop = np.zeros((PopSize, DimSize))
FitPop = np.zeros(PopSize)

FuncNum = 0

H = 5
muF = [0.3] * H
muCr = [0.5] * H

Fail_F = []
Fail_Cr = []


elms=[]

def meanL(arr):
    numer = 0
    denom = 0
    for var in arr:
        numer += var ** 2
        denom += var
    return numer / denom


def Initialization(func):
    global Pop, FitPop, curFEs, DimSize, muF, muCr, H, Fail_F, Fail_Cr
    for i in range(PopSize):
        for j in range(DimSize):
            Pop[i][j] = LB[j] + (UB[j] - LB[j]) * np.random.rand()
        FitPop[i],t = func(Pop[i])
        curFEs += 1
    muF = [0.5] * H
    muCr = [0.5] * H
    Fail_F, Fail_Cr = [], []

def ASHADE_MPC(func):
    global Pop, FitPop, LB, UB, PopSize, DimSize, curFEs, Fail_F, Fail_Cr
    Off = np.zeros((PopSize, DimSize))
    FitOff = np.zeros(PopSize)
    F_idx, Cr_idx = np.random.randint(H), np.random.randint(H)
    Success_F, Success_Cr = [], []
    P1 = 1 - curFEs / MaxFEs
    for i in range(PopSize):
        IDX1 = np.random.randint(0, PopSize)
        while IDX1 == i:
            IDX1 = np.random.randint(0, PopSize)
        candi = list(range(0, PopSize))
        candi.remove(i)
        candi.remove(IDX1)
        IDX2, r2, r3 = np.random.choice(candi, 3, replace=False)

        F = cauchy.rvs(muF[F_idx], 0.1)
        Cr = np.clip(np.random.normal(muCr[Cr_idx], 0.1), 0, 1)
        while True:  
            if F > 1:
                F = 1
                break
            elif F < 0:
                F = cauchy.rvs(muF[F_idx], 0.1)
            break

        if np.random.rand() < P1:
            if FitPop[IDX1] < FitPop[i] and FitPop[IDX2] < FitPop[i]:
                Off[i] = Pop[i] + F * (np.mean([Pop[IDX1], Pop[IDX2]], axis=0) - Pop[i]) + F * (Pop[r2] - Pop[r3])
            elif (FitPop[IDX1] < FitPop[i] and FitPop[IDX2] > FitPop[i]) or (
                    FitPop[IDX1] > FitPop[i] and FitPop[IDX2] < FitPop[i]):
                IDX = np.random.choice([IDX1, IDX2], 1, replace=False)[0]  
                Off[i] = Pop[i] + F * (
                        np.mean([Pop[IDX], Pop[np.argmin(FitPop)]], axis=0) - Pop[i]) + F * (
                                 Pop[r2] - Pop[r3])  
            else:
                Off[i] = Pop[i] + F * (Pop[np.argmin(FitPop)] - Pop[i]) + F * (Pop[r2] - Pop[r3])
        else:
            Off[i] = Pop[np.argmin(FitPop)] + F * (Pop[r2] - Pop[r3])

        jrand = np.random.randint(0, DimSize)  # bin crossover
        for j in range(DimSize):
            if np.random.rand() < Cr or j == jrand:
                pass
            else:
                Off[i][j] = Pop[i][j]

        for j in range(DimSize):
            if Off[i][j] < LB[j] or Off[i][j] > UB[j]:
                Off[i][j] = np.random.uniform(LB[j], UB[j])

        FitOff[i] ,t= func(Off[i])
        curFEs += 1
        if FitOff[i] < FitPop[i]:
            Success_F.append(F)
            Success_Cr.append(Cr)

    for i in range(PopSize):
        if FitOff[i] < FitPop[i]:
            Pop[i] = deepcopy(Off[i])
            FitPop[i] = FitOff[i]

    c = 0.1
    if len(Success_F) == 0:
        pass
    else:
        muF[F_idx] = (1 - c) * muF[F_idx] + c * meanL(Success_F)
    if len(Success_Cr) == 0:
        pass
    else:
        muCr[Cr_idx] = (1 - c) * muCr[Cr_idx] + c * np.mean(Success_Cr)



device = torch.device('cuda:0')
model1=SwinTransformerModel().to(device)
model2= Mobilenet_v2().to(device)
model3=ConvNeXtModel().to(device)
epochs=21

val_loader=[]
p1= np.array([])
p2=np.array([])
p3=np.array([])
def main():
    import numpy as np
    global x_train, y_train, x_val, y_val, device,elms,model1,model2,model3,val_loader
    lr = 1e-3
    batchsz = 64
    script_path = os.path.abspath(__file__)    
    cwd_dir = os.path.dirname(script_path)  
    model_name = ["mobilenet_v2_model", "SwinTransformerModel","ConvNeXtModel"]    
    for index  in range(len(model_name)): 
        
        All_Trial_Best = []
        elm_acc = []
        model_acc=[]
        val_model_acc=[]

        All_test_lable = []
        All_val_lable = []

        All_model_test_lable = []
        All_model_val_lable = []
        #Set the number of repeated executions to be consistent with the number 
        #of repetitions of the generative model. It is recommended to reduce the number of repetitions.     
        for ii in range(0, 30):            
            set_seed(42+index+ii )            
            if model_name[index]=="mobilenet_v2_model":                
                model=Mobilenet_v2().to(device)
            elif model_name[index]=="SwinTransformerModel":
                model=SwinTransformerModel().to(device)
            elif model_name[index]=="ConvNeXtModel":
                model=ConvNeXtModel().to(device)            
            else:
                pass

            print(f"Execute model {model_name[index]}: {ii}th time -------------")
            
            filemame = f"images{0}.csv"           
            train_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='train')
            val_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='val')
            test_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='test')       

            indices = np.arange(len(train_db))                
            sampler = SubsetRandomSampler(indices)          

            train_loader = DataLoader(train_db, batch_size=batchsz,  sampler=sampler)
            val_loader = DataLoader(val_db, batch_size=batchsz, shuffle=False)
            test_loader = DataLoader(test_db, batch_size=batchsz, shuffle=False)
             
            # Load the values of the trained model
            model.load_state_dict(torch.load(f'{cwd_dir}/{model_name[index]}/{str(epochs)}/best{ii}.mdl'))
            
            model1.load_state_dict(torch.load(f'{cwd_dir}/SwinTransformerModel/{str(epochs)}/best{ii}.mdl'))
            model2.load_state_dict(torch.load(f'{cwd_dir}/mobilenet_v2_model/{str(epochs)}/best{ii}.mdl'))
            model3.load_state_dict(torch.load(f'{cwd_dir}/ConvNeXtModel/{str(epochs)}/best{ii}.mdl'))

            # The path where the generated features are stored, so that the next time get_features is called, it can directly read the existing feature files.
            file_path = os.path.join(cwd_dir, f'data/x_train{ii}_{model_name[index]}_50dim.pkl')
            file_path1 = os.path.join(cwd_dir, f'data/y_train{ii}_{model_name[index]}_50dim.pkl')
            file_path2 = os.path.join(cwd_dir, f'data/x_val{ii}_{model_name[index]}_50dim.pkl')
            file_path3 = os.path.join(cwd_dir, f'data/y_val{ii}_{model_name[index]}_50dim.pkl')
            file_path4 = os.path.join(cwd_dir, f'data/test{ii}_{model_name[index]}_50dim.pkl')
            file_path5 = os.path.join(cwd_dir, f'data/test_y{ii}_{model_name[index]}_50dim.pkl')


            # Obtain training, validation, and test data
            train, train_y = get_features(model, train_loader, file_path, file_path1,model_name[index])
            val, val_y = get_features(model, val_loader, file_path2, file_path3,model_name[index])
            test, test_y = get_features(model, test_loader, file_path4, file_path5,model_name[index])

            x_train = train
            y_train = train_y
            x_val, y_val = val, val_y
                    
            from keras.utils import to_categorical
            y_train = to_categorical(train_y, 4)
            y_test = to_categorical(test_y, 4)
            y_val = to_categorical(val_y, 4)

            
            dimensions = 3            
            lb = np.ones(dimensions)*0
            ub = np.ones(dimensions)*1
            
            global curFEs, curFEs, TrialRuns, Pop, FitPop, DimSize,LB,UB,elms
            DimSize = dimensions
            LB =lb
            UB =ub           

            # Ensure output to standard output rather than a closed file
            sys.stdout = sys.__stdout__            
            All_Trial_Best = []
            MAX = 0
            for i in range(TrialRuns):
                BestList = []
                curFEs = 0
                np.random.seed(2000 + 22 * i)
                Initialization(softvote)
                BestList.append(min(FitPop))
                while curFEs < MaxFEs:
                    ASHADE_MPC(softvote)
                    BestList.append(min(FitPop))
                    min_index=np.argmin(FitPop)
                    _,elms=softvote(Pop[min_index])
                All_Trial_Best.append(BestList)
            
            
            val_acc,val_y_pred =getvote(elms,val_loader,model1,model2,model3,y_val)            
            acc ,y_pred  =getvote(elms,test_loader,model1,model2,model3,y_test)           
            elm_acc.append(acc)

            All_test_lable.append(y_pred)
            All_val_lable.append(val_y_pred)
 
            if model_name[index]=="mobilenet_v2_model":               
                model0=Mobilenet_v2().to(device)        
                  
            elif model_name[index]=="SwinTransformerModel":
                model0=SwinTransformerModel().to(device)
            elif model_name[index]=="ConvNeXtModel":
                model0=ConvNeXtModel().to(device)            
            else:
                pass
            
            model0.load_state_dict(torch.load(f'{cwd_dir}/{model_name[index]}/{str(epochs)}/best{ii}.mdl'))
            val_acc,val_pred_y0 = get_evaluate_acc_pred0(model0, val_loader)
            val_model_acc.append(val_acc)
            test_acc ,test_pred_y0= get_evaluate_acc_pred0(model0, test_loader)
            model_acc.append(test_acc)
            All_model_test_lable.append(test_pred_y0)
            All_model_val_lable.append(val_pred_y0)   
            
        
        print(f"test_集成模型:平均精度：", np.mean(elm_acc))
        print(f"test_基础模型_{model_name[index]}:平均精度：", np.mean(model_acc))                 
        
        

def getvote(X,loader,model1,model2,model3,y_val):

    p1 = get_evaluate_acc_pred(model1,loader)
    p2 = get_evaluate_acc_pred(model2, loader)
    p3 = get_evaluate_acc_pred(model3, loader)


    pred_prob1 = torch.tensor(p1, dtype=torch.float32)
    pred_prob2 = torch.tensor(p2, dtype=torch.float32)
    pred_prob3 = torch.tensor(p3, dtype=torch.float32)  
    
    weights = [X[0], X[1], X[2]]  

    
    weighted_prob = (
        weights[0] * pred_prob1 +
        weights[1] * pred_prob2 +
        weights[2] * pred_prob3
    ) / sum(weights)
    
    y_pred = np.argmax(weighted_prob, axis=1)
    y = np.argmax(y_val,axis=1)
    accuracy = accuracy_score(y, y_pred)    
    return accuracy,y_pred

def softvote(X):

    global model1,model2,model3,val_loader,p1,p2,p3
    
    if len(p1) == 0:
        p1 = get_evaluate_acc_pred(model1, val_loader)
        p2 = get_evaluate_acc_pred(model2, val_loader)
        p3 = get_evaluate_acc_pred(model3, val_loader)
    pred_prob1 = torch.tensor(p1, dtype=torch.float32)
    pred_prob2 = torch.tensor(p2, dtype=torch.float32)
    pred_prob3 = torch.tensor(p3, dtype=torch.float32)  
    weights = [X[0], X[1], X[2]]  

    weighted_prob = (
        weights[0] * pred_prob1 +
        weights[1] * pred_prob2 +
        weights[2] * pred_prob3
    ) / sum(weights)

    y_pred = np.argmax(weighted_prob, axis=1)
    y =np.argmax(y_val, axis=1)
    accuracy = accuracy_score(y, y_pred)    
    return -1*accuracy,X


def get_features(model, train_loader, x_path, y_path,modelname):
    global device
    if (not os.path.exists(x_path)) or (not os.path.exists(y_path)):
        
        
        if modelname =='SwinTransformerModel':
           model.base.head[-1] =nn.Identity()
           model0 =model
        elif modelname =='ConvNeXtModel':
            model.base.classifier[2][-1]=nn.Identity()
            model0 =model
        else:
           model.block[3]=nn.Identity()
           model0 = model
        model0=model
        model0.eval()
        for step, (x, y) in enumerate(train_loader):
            x, y = x.to(device), y.to(device)
            with torch.no_grad(): 
                logits = model0(x)
                features =logits                  
                if step == 0:
                    result = features
                    result_y = y
                else:
                    result = torch.cat([result, features], dim=0)
                    result_y = torch.cat([result_y, y], dim=0)
        result, result_y = result.cpu(), result_y.cpu()
        with open(x_path, 'wb') as file:
            pickle.dump(result, file)
        with open(y_path, 'wb') as file:
            pickle.dump(result_y, file)
        return result.numpy(), result_y.numpy()
    else:
        with open(x_path, 'rb') as file:
            result = pickle.load(file)
        with open(y_path, 'rb') as file:
            result_y = pickle.load(file)
        return result.numpy(), result_y.numpy()

 
 
 
#First, you need to run the generativeModel to generate the base model, 
#then run main to load the generated base model for integration.
if __name__ == '__main__':

    # generativeModel() #Generate a foundation model
    main() #Integrated model
